const { getDriver } = require('./db');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { TypedValues } = require('ydb-sdk');

// Secret for JWT - in production use Environment Variable!
const JWT_SECRET = process.env.JWT_SECRET || 'dev-secret-key-change-me';

module.exports.handler = async function (event, context) {
    console.log('Handler started');
    console.log('Event path:', event.path);
    console.log('Event method:', event.httpMethod);

    const { httpMethod, path, body, headers } = event;
    let driver;
    try {
        driver = await getDriver();
    } catch (dbError) {
        console.error('DB Connection Failed:', dbError);
        return {
            statusCode: 500,
            body: JSON.stringify({ error: 'DB Connection Failed: ' + dbError.message })
        };
    }

    // CORS Headers
    const responseHeaders = {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'POST, GET, OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type, Authorization'
    };

    if (httpMethod === 'OPTIONS') {
        return { statusCode: 200, headers: responseHeaders };
    }

    try {
        if (path === '/register' && httpMethod === 'POST') {
            return await register(driver, JSON.parse(body), responseHeaders);
        } else if (path === '/login' && httpMethod === 'POST') {
            return await login(driver, JSON.parse(body), responseHeaders);
        } else if (path === '/me' && httpMethod === 'GET') {
            return await me(driver, headers, responseHeaders);
        } else if (path === '/profile' && httpMethod === 'POST') {
            return await updateProfile(driver, headers, JSON.parse(body), responseHeaders);
        } else {
            return {
                statusCode: 404,
                headers: responseHeaders,
                body: JSON.stringify({ error: 'Not found' })
            };
        }
    } catch (e) {
        console.error(e);
        return {
            statusCode: 500,
            headers: responseHeaders,
            body: JSON.stringify({ error: e.message })
        };
    }
};

async function updateProfile(driver, requestHeaders, data, headers) {
    const authHeader = requestHeaders['Authorization'] || requestHeaders['authorization'];
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
        return { statusCode: 401, headers, body: JSON.stringify({ error: 'No token provided' }) };
    }
    const token = authHeader.split(' ')[1];
    let decoded;
    try {
        decoded = jwt.verify(token, JWT_SECRET);
    } catch (e) {
        return { statusCode: 401, headers, body: JSON.stringify({ error: 'Invalid token' }) };
    }
    const id = decoded.uid;

    const allowedFields = {
        'name': 'utf8',
        'age': 'uint32',
        'gender': 'utf8',
        'ethnicity': 'utf8',
        'religion': 'utf8',
        'zodiac': 'utf8',
        'about': 'utf8',
        'job': 'utf8',
        'interests': 'utf8',
        'photos': 'utf8',
        'macro_groups': 'utf8',
        'profile_completed': 'uint32'
    };

    const updates = [];
    const params = { '$id': TypedValues.utf8(id) };

    // Explicitly handle each field to ensure types
    for (const [key, type] of Object.entries(allowedFields)) {
        if (data[key] !== undefined) {
            updates.push(`${key} = $${key}`);
            if (type === 'uint32') {
                params[`$${key}`] = TypedValues.uint32(parseInt(data[key]) || 0);
            } else {
                params[`$${key}`] = TypedValues.utf8(String(data[key]));
            }
        }
    }

    if (updates.length === 0) {
        return { statusCode: 200, headers, body: JSON.stringify({ message: 'No updates' }) };
    }

    updates.push(`updated_at = $updated_at`);
    params['$updated_at'] = TypedValues.datetime(new Date());

    await driver.tableClient.withSession(async (session) => {
        const query = `
            DECLARE $id AS Utf8;
            ${Object.keys(params).filter(k => k !== '$id').map(k => `DECLARE ${k} AS ${k === '$updated_at' ? 'Datetime' : allowedFields[k.substring(1)] === 'uint32' ? 'Uint32' : 'Utf8'};`).join('\n')}
            
            UPDATE users SET ${updates.join(', ')} WHERE id = $id;
        `;
        await session.executeQuery(query, params);
    });

    return { statusCode: 200, headers, body: JSON.stringify({ success: true }) };
}

async function register(driver, data, headers) {
    const { email, password, name, age } = data;

    if (!email || !password) {
        return { statusCode: 400, headers, body: JSON.stringify({ error: 'Missing email or password' }) };
    }

    // Hash password
    const salt = await bcrypt.genSalt(10);
    const hash = await bcrypt.hash(password, salt);

    const id = require('crypto').randomUUID(); // generate UUID
    const createdAt = new Date().toISOString();

    await driver.tableClient.withSession(async (session) => {
        const query = `
            DECLARE $id AS Utf8;
            DECLARE $email AS Utf8;
            DECLARE $password_hash AS Utf8;
            DECLARE $name AS Utf8;
            DECLARE $age AS Uint32;
            DECLARE $created_at AS Datetime;

            INSERT INTO users (id, email, password_hash, name, age, created_at)
            VALUES ($id, $email, $password_hash, $name, $age, $created_at);
        `;

        await session.executeQuery(query, {
            '$id': TypedValues.utf8(id),
            '$email': TypedValues.utf8(email),
            '$password_hash': TypedValues.utf8(hash),
            '$name': TypedValues.utf8(name || ''),
            '$age': TypedValues.uint32(parseInt(age) || 0),
            '$created_at': TypedValues.datetime(new Date(createdAt))
        });
    });

    // Generate token
    const token = jwt.sign({ uid: id, email }, JWT_SECRET, { expiresIn: '7d' });

    return {
        statusCode: 201,
        headers,
        body: JSON.stringify({
            token,
            user: {
                uid: id,
                email,
                displayName: name,
                photoURL: null,
                emailVerified: false
            }
        })
    };
}

async function login(driver, data, headers) {
    const { email, password } = data;

    let user = null;

    await driver.tableClient.withSession(async (session) => {
        const query = `
            DECLARE $email AS Utf8;
            SELECT * FROM users WHERE email = $email LIMIT 1;
        `;
        const { resultSets } = await session.executeQuery(query, {
            '$email': TypedValues.utf8(email)
        });

        const rows = require('ydb-sdk').TypedData.decodeResultSet(resultSets[0]);
        if (rows.length > 0) {
            user = {
                uid: rows[0].id,
                email: rows[0].email,
                password_hash: rows[0].password_hash,
                name: rows[0].name,
                age: rows[0].age
            };
        }
    });

    if (!user) {
        return { statusCode: 401, headers, body: JSON.stringify({ error: 'User not found' }) };
    }

    const isValid = await bcrypt.compare(password, user.password_hash);
    if (!isValid) {
        return { statusCode: 401, headers, body: JSON.stringify({ error: 'Invalid password' }) };
    }

    const token = jwt.sign({ uid: user.uid, email: user.email }, JWT_SECRET, { expiresIn: '7d' });

    return {
        statusCode: 200,
        headers,
        body: JSON.stringify({
            token,
            user: {
                uid: user.uid,
                email: user.email,
                displayName: user.name,
                photoURL: null,
                emailVerified: false
            }
        })
    };
}

async function me(driver, requestHeaders, headers) {
    const authHeader = requestHeaders['Authorization'] || requestHeaders['authorization'];
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
        return { statusCode: 401, headers, body: JSON.stringify({ error: 'No token provided' }) };
    }

    const token = authHeader.split(' ')[1];

    try {
        const decoded = jwt.verify(token, JWT_SECRET);
        // Could fetch fresh data from DB here if needed
        return {
            statusCode: 200,
            headers,
            body: JSON.stringify({
                user: {
                    uid: decoded.uid,
                    email: decoded.email,
                    emailVerified: false
                }
            })
        };
    } catch (e) {
        return { statusCode: 401, headers, body: JSON.stringify({ error: 'Invalid token' }) };
    }
}
